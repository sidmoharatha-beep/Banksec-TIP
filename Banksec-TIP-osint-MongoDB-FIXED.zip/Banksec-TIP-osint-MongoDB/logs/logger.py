"""
logs/logger.py
Centralised logging for BankSec-TIP.
"""

import logging
import os

LOG_FILE = os.path.join(os.path.dirname(__file__), "banksec_tip.log")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler(),
    ],
)

logger = logging.getLogger("banksec_tip")
