"""
feeds/shodan_feed.py
Shodan – Advanced OSINT: find internet-exposed banking/finance services.
Searches for open ports commonly abused in financial-sector attacks.

API key location: .env  →  SHODAN_API_KEY
"""

import os
import time
import shodan
from dotenv import load_dotenv
from database.mongo_handler import ioc_data_collection

load_dotenv()

API_KEY = os.getenv("SHODAN_API_KEY")
if not API_KEY:
    raise EnvironmentError("[Shodan] SHODAN_API_KEY not set in .env")

api = shodan.Shodan(API_KEY)

# Queries targeting exposed financial infrastructure
SEARCH_QUERIES = [
    "port:3306 country:IN",            # Open MySQL (DB leaks)
    "port:27017 MongoDB",              # Exposed MongoDB
    "port:9200 elasticsearch",         # Exposed Elasticsearch
    "port:22 banner:OpenSSH default",  # Default SSH banners
]


def ingest(max_results_per_query: int = 50) -> int:
    """Search Shodan and store exposed-host records."""
    print("[Shodan] Starting advanced OSINT scan...")
    inserted = 0

    for query in SEARCH_QUERIES:
        print(f"  [~] Query: {query}")
        try:
            results = api.search(query, limit=max_results_per_query)
            for match in results.get("matches", []):
                ip   = match.get("ip_str")
                port = match.get("port")
                ioc  = {
                    "source":      "Shodan",
                    "indicator":   ip,
                    "type":        "IPv4",
                    "port":        port,
                    "org":         match.get("org", ""),
                    "country":     match.get("location", {}).get("country_name", ""),
                    "risk_score":  70,
                    "shodan_query": query,
                    "status":      "exposed",
                }
                exists = ioc_data_collection.find_one({
                    "source":    "Shodan",
                    "indicator": ip,
                    "port":      port,
                })
                if not exists:
                    ioc_data_collection.insert_one(ioc)
                    inserted += 1
                    print(f"      [+] {ip}:{port}  ({ioc['country']})")
            time.sleep(1)  # Shodan rate-limit courtesy
        except shodan.APIError as e:
            print(f"  [!] Shodan API error: {e}")

    print(f"[Shodan] Done – {inserted} exposed hosts inserted.\n")
    return inserted


if __name__ == "__main__":
    ingest()
