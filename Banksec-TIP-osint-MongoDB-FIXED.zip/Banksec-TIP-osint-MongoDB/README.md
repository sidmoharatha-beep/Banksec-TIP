# BankSec-TIP — OSINT & MongoDB Branch
**Assigned to: Chayan Soni**

## Overview
This branch handles **Week 1 & 2** of the project:
- Multi-source OSINT threat feed ingestion (AlienVault OTX, AbuseIPDB, VirusTotal, Shodan)
- Data normalisation and deduplication
- Storage in MongoDB `threat_intelligence` database

## Pipeline
```
OSINT Feeds (AlienVault / AbuseIPDB / VirusTotal / Shodan)
         ↓
    MongoDB: ioc_data  (raw)
         ↓
    ioc_extractor.py
         ↓
    MongoDB: threats   (normalised)
         ↓
  [Next: ELK branch picks up from here]
```

## Setup

```bash
# 1. Clone and enter the repo
git clone <repo-url>
cd Banksec-TIP
git checkout osint-mongodb

# 2. Create virtual environment
python3 -m venv venv
source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure API keys
cp .env.example .env
# Edit .env and add your API keys (see .env.example for details)

# 5. Start MongoDB
sudo systemctl start mongod

# 6. Run pipeline
python main.py
```

## API Key Locations
| Key | File | Variable Name |
|-----|------|---------------|
| AlienVault OTX | `.env` | `OTX_API_KEY` |
| AbuseIPDB | `.env` | `ABUSEIPDB_API_KEY` |
| VirusTotal | `.env` | `VIRUSTOTAL_API_KEY` |
| Shodan | `.env` | `SHODAN_API_KEY` |

## Technologies
- Python 3.10+, PyMongo, python-dotenv, Requests, Shodan SDK
- MongoDB (local, port 27017)
- Kali Linux
